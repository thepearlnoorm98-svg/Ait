Price Alert Flutter Starter
==========================

This is a minimal Flutter starter to monitor a cryptocurrency price (using Binance public API)
and show local notifications when the price changes by a threshold percentage.

How to use
1. Install Flutter SDK and set up Android toolchain (Android Studio).
   https://flutter.dev/docs/get-started/install

2. Create a new Flutter project:
   flutter create price_alert_app
   cd price_alert_app

3. Replace the project's pubspec.yaml with the provided pubspec.yaml file, and replace
   lib/main.dart with the provided main.dart.

4. Get dependencies:
   flutter pub get

5. Run the app on an Android device/emulator:
   flutter run

Notes
- This starter polls Binance's public REST API every 10 seconds. For production use,
  consider websockets, back-end rate limits, and better state management.
- For Android notifications, the app uses flutter_local_notifications. You may need
  additional Android setup for some devices (foreground service, battery optimizations).
- This is a starting template — you can extend it to:
  * add multiple symbols
  * persistent user settings (thresholds)
  * push notifications via Firebase Cloud Messaging
  * include news sentiment analysis (separate service)
