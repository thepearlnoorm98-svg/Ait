import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String symbol = "BTCUSDT";
  double lastPrice = 0.0;
  double thresholdPercent = 1.0; // percent
  Timer? timer;
  String status = "Stopped";
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  @override
  void initState() {
    super.initState();
    _initNotifications();
  }

  Future<void> _initNotifications() async {
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    final InitializationSettings initializationSettings =
        InitializationSettings(android: initializationSettingsAndroid);

    await flutterLocalNotificationsPlugin.initialize(initializationSettings);
  }

  Future<double> fetchPrice(String symbol) async {
    final url = Uri.parse('https://api.binance.com/api/v3/ticker/price?symbol=$symbol');
    final resp = await http.get(url).timeout(Duration(seconds: 10));
    final data = json.decode(resp.body);
    return double.parse(data['price']);
  }

  void startMonitoring() async {
    setState(() {
      status = "Running";
    });
    try {
      lastPrice = await fetchPrice(symbol);
    } catch (e) {
      print('initial fetch failed: $e');
      lastPrice = 0.0;
    }

    timer?.cancel();
    timer = Timer.periodic(Duration(seconds: 10), (t) async {
      try {
        final current = await fetchPrice(symbol);
        if (lastPrice > 0) {
          final changePercent = ((current - lastPrice) / lastPrice) * 100.0;
          if (changePercent.abs() >= thresholdPercent) {
            _showNotification(
                'Price Alert',
                'Symbol: $symbol\nChange: ${changePercent.toStringAsFixed(2)}%\nPrice: \$${current.toStringAsFixed(2)}'
            );
            // Update lastPrice to avoid repeated alerts for same move
            lastPrice = current;
          }
        } else {
          lastPrice = current;
        }
        setState(() {});
      } catch (e) {
        print('fetch error: $e');
      }
    });
  }

  void stopMonitoring() {
    timer?.cancel();
    setState(() {
      status = "Stopped";
    });
  }

  Future<void> _showNotification(String title, String body) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails('price_alerts', 'Price Alerts',
            channelDescription: 'Alerts when price moves',
            importance: Importance.high,
            priority: Priority.high,
            ticker: 'ticker');

    const NotificationDetails platformChannelSpecifics =
        NotificationDetails(android: androidPlatformChannelSpecifics);

    await flutterLocalNotificationsPlugin.show(
        0, title, body, platformChannelSpecifics,
        payload: 'price_alert');
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Price Alert Starter',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Price Alert Starter'),
        ),
        body: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              TextField(
                decoration: InputDecoration(labelText: 'Symbol (e.g. BTCUSDT)'),
                controller: TextEditingController(text: symbol),
                onChanged: (v) => symbol = v.trim(),
              ),
              SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      decoration: InputDecoration(labelText: 'Threshold %'),
                      keyboardType: TextInputType.numberWithOptions(decimal: true),
                      controller: TextEditingController(text: thresholdPercent.toString()),
                      onChanged: (v) {
                        final parsed = double.tryParse(v);
                        if (parsed != null) thresholdPercent = parsed;
                      },
                    ),
                  ),
                  SizedBox(width: 8),
                  ElevatedButton(
                      onPressed: startMonitoring,
                      child: Text('Start')
                  ),
                  SizedBox(width: 8),
                  ElevatedButton(
                      onPressed: stopMonitoring,
                      child: Text('Stop')
                  ),
                ],
              ),
              SizedBox(height: 20),
              Text('Status: \$${lastPrice.toStringAsFixed(2)}  —  $status'),
              SizedBox(height: 12),
              Text('Polling every 10 seconds.'),
            ],
          ),
        ),
      ),
    );
  }
}
